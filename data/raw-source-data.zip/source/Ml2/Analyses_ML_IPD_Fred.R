##############################################################################
##### APPLYING RANDOM-EFEFCTS, MULTILEVEL, AND IPD META-ANALYSIS METHODS #####
##### TO THE DATA OF MANY LABS 2                                         #####
##### Author: Robbie C.M. van Aert                                       #####
##############################################################################

rm(list = ls())

### Set working directory
setwd("C:/Users/S787802/Desktop/TEST")

################
### PACKAGES ###
################

install.packages(c("devtools", "tidyverse", "XLConnect", "metafor", "highr"))
library(devtools)
library(tidyverse)
library(XLConnect)
library(metafor)
library(highr)

#################
### FUNCTIONS ###
#################

### Source code and data of Many Labs 2
source_url("https://raw.githubusercontent.com/ManyLabsOpenScience/ManyLabs2/master/Script%20-%20Sourceable%20function%20library/manylabRs_SOURCE.R")

### Modify the function get.analyses() in order to get all effect size estimates
# Changes to this file can be found by searching for "# Robbie:"
source("get.analyses_1.R")

### Function now() was not in the source code of Many Labs 2 and caused an error
now <- function() { Sys.time() }

################################################################################

### Load ML2_masteRkey
wb <- loadWorkbook("OSFdata/!!KeyTables/ML2_masteRkey.xlsx")
masterkey <- readWorksheet(wb, sheet = 1)

### Select only primary analyses
sub <- subset(masterkey, masterkey$study.primary.include == 1)

### Empty object for storing results
Q <- numeric(nrow(sub))

for (i in 1:nrow(sub))
{
  
  ### Get data
  dat <- try(get.analyses(studies = sub$unique.id[i], analysis.type = 2, 
                          rootdir = "OSFdata", 
                          indir = list(RAW_DATA = "OSFdata/!!RawData",
                                       MASTERKEY = "OSFdata/!!KeyTables",
                                       SOURCE_INFO = "OSFdata/!!KeyTables"), 
                          data.names = list(Slate1 = "ML2_Slate1.rds", Slate2 = "ML2_Slate2.rds")))
  
  if (class(dat) == "try-error")
  { # Check if data could be extracted, if not return NA
    Q[i] <- NA
  } else 
  { 
    dat_sum <- eval(parse(text = paste0("dat$aggregated$", sub$study.analysis[i])))
    
    if (all(is.na(dat_sum$ESCI.r)))
    { # Check if correlations are available, if not return NA
      Q[i] <- NA
    } else 
    { # Conduct a random-effects meta-analysis and store Q-statistic
      uni <- rma(yi = ESCI.r, vi = ESCI.var.r, data = dat_sum)
      Q[i] <- uni$QE
    }
    
  }
  
}

### Save dataframe with Q-statistics
res <- data.frame(study.analysis = sub$study.analysis, Q = round(Q, 2))
write.csv(res, file = "res.csv")

################################################################################

#################################################
### INDIVIDUAL PARTICIPANT DATA META-ANALYSIS ###
#################################################

### Load data for Slate 1 and Slate 2
ML2_Slate1 <- readRDS("ML2_Slate1.rds")
ML2_Slate2 <- readRDS("ML2_Slate2.rds")

### Get data for Kay.1
runningAnalysis <- 7
dat <- get.analyses(studies = runningAnalysis, analysis.type = 2, 
                    rootdir = "OSFdata", 
                    indir = list(RAW_DATA = "OSFdata/!!RawData",
                                 MASTERKEY = "OSFdata/!!KeyTables",
                                 SOURCE_INFO = "OSFdata/!!KeyTables"), 
                    data.names = list(Slate1 = "ML2_Slate1.rds", Slate2 = "ML2_Slate2.rds"))

dat_sum <- eval(parse(text = paste0("dat$aggregated$", sub$study.analysis[i])))

### Different labs
runningGroups <- as.character(dat$aggregated$Kay.1$study.source)

### Empty object for storing results
dat_IPD <- list()

# Get information about the analysis to run
masteRkeyInfo  <- get.GoogleSheet(data='ML2masteRkey')$df[runningAnalysis,]

# Organise the information into a list object
analysisInfo   <- get.info(masteRkeyInfo, colnames(ML2_Slate1), subset="all")

# Use analysisInfo to generate a cahin of filter instructions to select valid variables and cases
filterChain <- get.chain(analysisInfo)

# Apply the filterChain to select aprropriate variables from ML2.S1
df.raw <- eval(parse(text=paste("ML2_Slate1", filterChain$df)))

### Loop to get data of different labs in a list
for (m in 1:length(runningGroups))
{
  
  # Apply the filterChain to generate a list object that represents the design cells
  df.split <- get.sourceData(filterChain, df.raw[df.raw$source%in%runningGroups[m],], analysisInfo)
  
  # Create a list object with data vectors and appropriate labels, that can be passed to the analysis function
  vars   <- eval(parse(text=paste0(masteRkeyInfo$stat.vars,'(df.split)',collapse="")))
  
  ### Add information on labs and source.Country to vars and store in a list
  vars$cleanDataFilter$study.source <- runningGroups[m]
  vars$cleanDataFilter$source.Country <- dat_sum$source.Country[m]
  dat_IPD[[m]] <- vars$cleanDataFilter
  
}

### Bind all the lists to get a dataframe
dat_IPD <- do.call(rbind, dat_IPD)

### Conduct a t-test
sub_Order <- subset(dat_IPD, dat_IPD$factor == "Order")
sub_DisOrder <- subset(dat_IPD, dat_IPD$factor == "DisOrder")
t.test(x = sub_Order$variable, y = sub_DisOrder$variable, conf.level = 0.95, 
       var.equal = FALSE, alternative = "two.sided")
